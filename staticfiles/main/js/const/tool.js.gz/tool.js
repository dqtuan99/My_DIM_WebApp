export const TOOL_DRAGGER = 'dragger';
export const TOOL_PAINT_BUCKET = 'paint-bucket';
export const TOOL_BRUSH = 'brush';
export const TOOL_ERASER = 'eraser';