export const COLOR_UNCERTAIN = '#808080';
export const COLOR_CERTAIN = '#37d61a';