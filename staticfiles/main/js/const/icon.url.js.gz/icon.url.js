export const TOGGLE_ON_URL = 'http://127.0.0.1:8000/static/main/image/on.svg';
export const TOGGLE_OFF_URL = 'http://127.0.0.1:8000/static/main/image/off.svg';